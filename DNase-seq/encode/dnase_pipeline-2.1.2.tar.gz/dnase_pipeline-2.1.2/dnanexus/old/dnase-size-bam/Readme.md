<!-- dx-header -->
# DNase-seq (DNAnexus Platform App)

Conditionally reduce the bam size to a target, or no larger than a limit of reads for the ENCODE DNase-seq pipeline.

This is the source code for an app that runs on the DNAnexus Platform.
For more information about how to run or modify it, see
https://wiki.dnanexus.com/.
<!-- /dx-header -->

