<!-- dx-header -->
# DNase-seq (DNAnexus Platform App)

Evaluates sample of (paired-end) bam for the ENCODE DNase-seq pipeline.

This is the source code for an app that runs on the DNAnexus Platform.
For more information about how to run or modify it, see
https://wiki.dnanexus.com/.
<!-- /dx-header -->

