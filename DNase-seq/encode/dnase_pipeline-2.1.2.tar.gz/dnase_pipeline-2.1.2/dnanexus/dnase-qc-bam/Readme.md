<!-- dx-header -->
# DNase-seq (DNAnexus Platform App)

Evaluates sample of aligned reads with HotSpot1, pbc and spp for the ENCODE DNase-seq pipeline.

This is the source code for an app that runs on the DNAnexus Platform.
For more information about how to run or modify it, see
https://wiki.dnanexus.com/.
<!-- /dx-header -->

