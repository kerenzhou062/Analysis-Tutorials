<!-- dx-header -->
# DNase-seq (DNAnexus Platform App)

Merge and filter bams (single-end) for the ENCODE DNase-seq pipeline.

This is the source code for an app that runs on the DNAnexus Platform.
For more information about how to run or modify it, see
https://wiki.dnanexus.com/.
<!-- /dx-header -->

